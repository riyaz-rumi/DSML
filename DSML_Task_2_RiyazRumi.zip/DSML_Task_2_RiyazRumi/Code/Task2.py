
# Mathematical operations | Written By: Riyaz Rumi | 4/9/2025
import numpy as np

#--------------------------------------------------------------------------------------     
# Single Linear Equation: ax + b = 0
def single_linear_equation(coef):
    print(f'\nSingle Linear Equation:')
    x = -coef[1] / coef[0]
    print(f'{coef[0]}x + ({coef[1]}) = 0\nx = {x}')

coef = np.array([5, -10])
single_linear_equation(coef)

#--------------------------------------------------------------------------------------     
# Multi Linear Equation: ax + by = 0
def multi_linear_equation(coef, vec):
    print(f'\nMulti Linear Equation:')
    print(f'{coef[0][0]}x + {coef[0][1]}y = {vec[0]}')
    print(f'{coef[1][0]}x + {coef[1][1]}y = {vec[1]}')

    determinant = np.linalg.det(coef)
    print(f"\nDeterminant: {determinant:.2f}")

    if (determinant != 0):
        solution = np.linalg.solve(coef, vec)
        print(f"x = {solution[0]:.2f}, y = {solution[1]:.2f}")
        # least-squares solution (for non-square or singular matrices)
        solution, residuals, rank, s = np.linalg.lstsq(coef, vec)
        print("\nLeast-Squares Solution (To be done when determinant is zero):")
        print(f"x = {solution[0]:.2f}, y = {solution[1]:.2f}")
        print(f"Residuals: {residuals}")
        print(f"Rank of coef: {rank}")

coef = np.array([[5, 6], [3, 2]])
vec = np.array([29, 11])
multi_linear_equation(coef, vec) 

#--------------------------------------------------------------------------------------     
# Quadratic Equation: ax^2 + bx + c = 0
def quadratic_linear_equation(coef):
    print(f'\nQuadratic Linear Equation:')
    a, b, c = coef
    if a == 0:
        print('Warning: Not a quadratic equation!')
    
    D = b**2 - 4*a*c    
    if D == 0:
        x = -b / 2*a
        print(f'One Real Solution: \n x = {x}')
    elif D > 0:
        x1 = (-b + np.sqrt(D)) / (2*a)
        x2 = (-b - np.sqrt(D)) / (2*a)
        print(f'Two Real Solution: \n x1 = {x1}, x2 = {x2}')
    else:
        real = -b / 2*a
        imag = np.sqrt(-D) / 2*a
        print(f'Complex Solution: \n x1 = {real} + {imag}j, x2 = {real} + {imag}j')

coef = np.array([1, -3, 2])  # x^2 - 3x + 2 = 0 -> roots: 1 and 2
quadratic_linear_equation(coef)