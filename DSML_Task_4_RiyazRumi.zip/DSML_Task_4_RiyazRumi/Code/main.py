
# Advanced Data Cleaning with Fuzzy String Matching | Written By: Riyaz Rumi | 6/9/25
import pandas as pd
from methods import find_duplicates, deduplicate, save_deduplicate, plot_histogram

THRESHOLD = 80 # Adjustable threshold

def main():
    # Loading dataset
    df_original = pd.read_csv('tested.csv')
    names = df_original['Name'].dropna()

    # Finding duplicates
    df_duplicates = find_duplicates(data=names, threshold=THRESHOLD)
    print(f'\n{df_duplicates}\nTotal {len(df_duplicates)} on {THRESHOLD}% threshold.')

    # Plotting histogram
    similarities = df_duplicates["Similarity"].tolist()
    plot_histogram(similarities, threshold=THRESHOLD)

    # Asking user for action
    if input('\nTake Action: Remove Similar Data? Yes / No > ').lower() == 'yes':
        df_cleaned = deduplicate(df_original, df_duplicates)
        print(f'{len(df_duplicates)} duplicate rows removed!')
        save_deduplicate(df_cleaned)

if __name__ == "__main__":
    main()
