import pandas as pd
from rapidfuzz import fuzz, process
import matplotlib.pyplot as plt

def find_duplicates(data, threshold):
    possible_duplicates = []
    for i, val in enumerate(data):
        matches = process.extract(val, data[i+1:], scorer=fuzz.token_sort_ratio, limit=None)
        for similar_val, score, _ in matches:
            if score >= threshold:
                possible_duplicates.append((val, similar_val, score))
    
    df_duplicates = pd.DataFrame(possible_duplicates, columns=['Name', 'Similar Name', 'Similarity']).sort_values(by="Similarity", ascending=False)
    return df_duplicates

def deduplicate(df_original, df_duplicates):
    names_to_drop = set(df_duplicates['Similar Name']) 
    df_cleaned = df_original[~df_original['Name'].isin(names_to_drop)]
    return df_cleaned

def plot_histogram(data, threshold):
    plt.hist(data, bins=20)
    plt.title(f'Distribution of Name Similarities')
    plt.xlabel(f"Similarity Score (threshold={threshold}%)")
    plt.ylabel("Frequency")
    plt.show()
    
def save_deduplicate(df_cleaned):
    df_cleaned.to_csv("titanic_cleaned.csv", index=False)
    print("\nCleaned dataset saved as titanic_cleaned.csv")
    