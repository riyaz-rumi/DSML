# Generating Geographical Heatmap | Written By: Riyaz Rumi | 5/9/25
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

df_countries = pd.read_csv("countries.csv")
latitudes = df_countries['latitude'].values
longitudes = df_countries['longitude'].values

# Create the figure and map
fig = plt.figure(figsize=(12, 7), dpi=110)
m = Basemap(projection='robin', lon_0=0, resolution='c')
m.drawcoastlines(linewidth=0.5)
m.drawcountries(linewidth=0.3)
m.drawmapboundary(fill_color='lightblue')
m.fillcontinents(lake_color='lightblue', zorder=0)

# Project coordinates
x, y = m(longitudes, latitudes)

# Hexbin heatmap (density of countries) & Colorbar
ax = plt.gca()
ax.set_title('Global Country Density Heatmap')
hb = ax.hexbin(x, y, gridsize=80, bins='log', cmap='inferno', mincnt=1)
cb = fig.colorbar(hb, ax=ax, shrink=0.7, pad=0.03)
cb.set_label('Log(Number of Countries per Hexagon)')

plt.tight_layout()
plt.show()

