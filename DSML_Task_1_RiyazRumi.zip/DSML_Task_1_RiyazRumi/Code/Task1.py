
# Handling hierarchical indexing | Written By: Riyaz Rumi | 3/9/2025
import pandas as pd
df = pd.read_csv("tested.csv")

# Build a MultiIndex from two columns
df = df.set_index(["Pclass", "Sex"]).sort_index() 

#--------------------------------------------------------------------------------------------------------
# Selection
df.head(5)
df.iloc[45:55]
# print(f'\n Top 5 Rows: \n {df.head(5)}')
# print(f'\n Rows from 45 to 55: \n {df.iloc[45:55]}')

#--------------------------------------------------------------------------------------------------------
# Selection / Filter
df.loc[3] # All passengers in 3rd class
df.xs(3, level=0) # All passengers in 3rd class
df.groupby("Pclass").size()[3] # All passengers in 3rd class

df.loc[(1, "female")] # Only 1st-class female passengers
df.loc[(1, "male"), :"Age"] # All male passengers from 1st class, COLUMNs: to Age
df.loc[1:2, "Name": "Fare"] # All passengers from 1 to 2 class, COLUMNs: from Name to Fare
df.loc[1, "Age":] # All passengers from 1st class, COLUMNs: Age to the last column
df.loc[:, "Name":"Fare"] # All passengers, COLUMNs: from Name to Fare

df.xs(3) # All passengers from 3rd class | Note: By Default level=0
df.xs("male", level=1) # All male passengers across all classes

df.groupby("Pclass").size()[2] # All passengers from 2nd class
df.groupby("Sex").size()["female"] # All female passengers across all classes

# print(f'\nTotal passengers in 3rd class: {len(df.loc[3])}')
# print(f'Total male passengers in 2nd class: {len(df.loc[(2, "male")])}')
# print(f'Total female passengers: {len(df.xs("female", level=1))}')
# print(f'Total male passengers: {df.groupby("Sex").size()["male"]}')

#--------------------------------------------------------------------------------------------------------
# Slice across levels
idx = pd.IndexSlice
df.loc[idx[1:2]] # All passengers from 1st class to 2nd class
df.loc[idx[:]] # All passengers
df.loc[idx[1, "female"]] # All female passengers of 1st class
df.loc[idx[1, "male"], "Name"] # All male passengers from 1 class with their Names
df.loc[idx[:, "male"], :] # All male passengers and their data
df.loc[idx[1:2, "male"], "Name":] # All male passengers from 1 to 2 class ,COLUMNs: from Name to the last column
# print(f'\nFemale passengers in 2nd and 3rd class: \n {df.loc[idx[2:3, "female"], "Name":"Fare"]}')

#--------------------------------------------------------------------------------------------------------
# Selection / Filter (Actual Usage)
partial_df = {
    "PClass" : [1, 2, 3, "Total"],
    "Male" : [
        len(df.loc[(1, "male")]),
        len(df.loc[(2, "male")]),
        len(df.loc[(3, "male")]),
        len(df.xs("male", level=1))
    ],
    "Female" : [
        len(df.loc[(1, "female")]),
        len(df.loc[(2, "female")]),
        len(df.loc[(3, "female")]),
        df.groupby("Sex").size()["female"]
    ],
    "Both" : [
        len(df.loc[1]),
        len(df.loc[2]),
        len(df.loc[3]),
        len(df)
    ]
}
summary = pd.DataFrame(partial_df)
print(summary)

#--------------------------------------------------------------------------------------------------------
# Rearrange levels
df = df.swaplevel(0, 1).sort_index() # Set Sex column at level=0, Pclass column at level=1
df.loc["male"] # All male passengers
df.xs(3, level=1) # All passengers from 3rd class
df.xs("male", level=0) # All male passengers
df.loc[idx["male", 2]] # All male passengers from 2nd class

df = df.reorder_levels([1,0]).sort_index() # Set Sex column at level=1, Pclass column at level=0
df.xs(3, level=0) # All passengers from 3rd class
df.xs("male", level=1) # All male passengers
df.loc[idx[2, "male"]] # All male passengers from 2nd class

#--------------------------------------------------------------------------------------------------------
# Aggregate by index level
df.groupby(level=0).sum(numeric_only=True) # Group by level=0 and sum all numeric columns of each group (Pclass)
df.groupby(level=1)["Fare"].mean() # Group by level=1 and calculate mean for Fare column of each group (Sex)
df.groupby(level=0)["Age"].median() # Group by level=0 and calculate median for Fare column of each group (Pclass)

# print(f'\n Group by level=0 (Pclass) and sum all numeric columns of each group \n {df.groupby(level=0).sum(numeric_only=True)}')
# print(f'\n Group by level=1 (Sex) and calculate mean for Fare column of each group \n {df.groupby(level=1)["Fare"].mean()}')
# print(f'\n Group by level=0 (Pclass) and calculate median for Age column of each group \n {df.groupby(level=0)["Age"].median()}')

# Reset / Remove index
df = df.reset_index()