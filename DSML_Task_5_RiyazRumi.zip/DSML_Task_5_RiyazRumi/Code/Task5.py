
# Advanced Data Visualization using Matplotlib | Written By: Riyaz Rumi | 8/9/2025
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
import pandas as pd
import numpy as np
from matplotlib import gridspec

# Prepare Dataset
iris = load_iris()
df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
df['species'] = pd.Categorical.from_codes(codes=iris.target, categories=iris.target_names)
x = df['sepal length (cm)']
y = df['petal length (cm)']

# Compute Linear Regression
m, b = np.polyfit(x, y, 1) # m: slope | b: intercept
y_pred = m*x + b
residuals = y - y_pred
SSE = np.sum(residuals ** 2) # Sum of Squared Error
n = len(df)
MSE = SSE / (n - 2) # Mean of Squared Error

# Compute 95% Confidence Interval (normal approximation)
SSx = np.sum((x - np.mean(x)) ** 2) # Sum of Squared of x
SEP = np.sqrt(MSE * (1/n + ((x - np.mean(x)) ** 2) / SSx)) # Standard Error of Prediction
z = 1.96 # 95% quantile of N(0,1)
CI_lower = y.mean() - (z * SEP)
CI_upper = y.mean() + (z * SEP)

# Rolling Mean for smoothing
df['rolling_mean_y'] = y.rolling(window=10, center=True, min_periods=1).mean()

# Identify Largest Residuals (outliers)
df['residual_abs'] = residuals.abs()
label_df = df.nlargest(n=5, columns='residual_abs').copy()
label_df['label'] = [f'{species}_{i+1}' for i, species in enumerate(label_df['species'])]

print("Sample of Iris DataFrame:\n", df) # Quick Preview of iris dataset

# Build Plot Layout with GridSpec
fig = plt.figure(figsize=(12, 9))
gs = gridspec.GridSpec(4, 4, hspace=0.5, wspace=0.5)
ax_main = fig.add_subplot(gs[1:4, 0:3])  # main scatter plot
ax_xhist = fig.add_subplot(gs[0, 0:3], sharex=ax_main)  # histogram above
ax_yhist = fig.add_subplot(gs[1:4, 3], sharey=ax_main)  # histogram to the right

# Scatter Plot per Species
markers = { "setosa": "o", "versicolor": "s", "virginica": "D" }
for species, mk in markers.items():
    subset = df[df['species'] == species]
    ax_main.scatter(subset['sepal length (cm)'], subset['petal length (cm)'], 
            label=species, marker=mk, alpha=0.7)

# Regression Line 
x_sorted = np.sort(x)
y_pred_line = m * x_sorted + b 
ax_main.plot(x_sorted, y_pred_line, linewidth=2, label='OLS Fit')

# Confidence Interval Band 95%
SE_sorted = np.interp(x_sorted, x, SEP)
CI_lower_sorted = y_pred_line - z * SE_sorted
CI_upper_sorted = y_pred_line + z * SE_sorted
ax_main.fill_between(x_sorted, CI_lower_sorted, CI_upper_sorted, alpha=0.2, label='95% CI Band')

# Rolling Mean Overlay
ax_main.plot(x, df['rolling_mean_y'], linestyle='--', linewidth=1.5, label='Rolling Mean (10)')

# Annotate Outliers
for _, row in label_df.iterrows():
    ax_main.annotate(row['label'], xy=(row['sepal length (cm)'], row['petal length (cm)']),
        xytext=(row['sepal length (cm)'] + 0.3, row['petal length (cm)'] + 0.5),
        arrowprops=dict(arrowstyle="->", lw=0.8), fontsize=8)

# Stats Summary Box 
stats_text = (
    f"n = {n}\n"
    f"slope = {m:.3f}\n"
    f"intercept = {b:.2f}\n"
    f"MSE = {MSE:.3f}\n"
    f"Std residual = {np.sqrt(MSE):.2f}"
)
ax_main.text(0.95, 0.05, stats_text, transform=ax_main.transAxes, 
        fontsize=8, ha='right', va='bottom', bbox=dict(boxstyle="round,pad=0.4", alpha=0.1))

# Labels, Legend, Grid 
ax_main.set_xlabel('Sepal Length (cm)')
ax_main.set_ylabel('Petal Length (cm)')
ax_main.set_title("Iris: Sepal vs Petal Length with OLS, CI, Rolling Mean, Outliers")
ax_main.legend(loc="upper left", fontsize=8)
ax_main.grid(True, linestyle=":")

# Marginal Histograms
ax_xhist.hist(x, bins=20)
ax_xhist.set_title("Sepal Length Distribution")
ax_xhist.tick_params(labelbottom=False)

ax_yhist.hist(y, bins=20, orientation='horizontal')
ax_yhist.set_title("Petal Length Distribution")
ax_yhist.tick_params(labelleft=False)

# Save and show Figure
plt.savefig("iris_advanced_viz.png", dpi=150, bbox_inches='tight')
plt.show()
print("Saved plot to iris_advanced_viz.png")

